import os,sys
sys.path.append(os.getcwd())
from selenium import webdriver
from resources.locators.variable import *
from resources.locators.locator import *
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
import time
import datetime
import logging

logging.basicConfig(filename="ctl_reservation.log",level=logging.INFO,format='%(asctime)s:%(levelname)s: %(message)s',filemode='w')

class Reservation_automation:
    def __init__(self,url=url,user=user,pwd=pwd,PD=PD):
        self.url = url
        self.user = user
        self.pwd = pwd
        self.PD = PD
        logging.info("the constuctor method is calling")

    def login_page(self):
        try:
            self.driver = webdriver.Chrome()
            self.driver.implicitly_wait(30)
            self.driver.get(url)
            self.driver.maximize_window()
            self.driver.find_element_by_id(username_id).send_keys(user)
            self.driver.find_element_by_id(password_name).send_keys(pwd)
            self.sign = self.driver.find_element_by_class_name(sign_in).click()
        except Exception as e:
            logging.info("failed with invalid username or password  {}".format(e))
            assert None, "failed to invalid username or password "

inst= Reservation_automation(url,user,pwd,PD)
inst.login_page()


