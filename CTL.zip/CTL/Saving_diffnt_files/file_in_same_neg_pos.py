import os,sys
sys.path.append(os.getcwd())
from selenium import webdriver
from resources.locators.variable import *
from resources.locators.locator import *
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
import time
from datetime import datetime
import logging

cur_dir = os.getcwd()
# Create a new directory to store saved screenshots
screens_path = cur_dir + os.path.sep + "screenshots1"
if not os.path.exists(screens_path):
    os.mkdir(screens_path)


logging.basicConfig(filename="ctl_reservation.log",level=logging.INFO,format='%(asctime)s:%(levelname)s: %(message)s',filemode='w')


class Reservation_automation:
    def __init__(self,url=url,user=user,pwd=pwd,PD=PD,flag=None):
        self.url = url
        self.user = user
        self.pwd = pwd
        self.PD = PD
        self.flag = flag
        logging.info("the constuctor method is calling")

    def invalid_login(self,u,p,flag):
        try:
            self.driver = webdriver.Chrome()
            self.driver.implicitly_wait(30)
            self.driver.get(url)
            self.driver.maximize_window()
            self.driver.find_element_by_id(username_id).send_keys(u)
            self.driver.find_element_by_id(password_name).send_keys(p)
            self.sign = self.driver.find_element_by_class_name(sign_in).click()
            a = self.driver.find_element_by_xpath(error_msg_xpath).text
            logging.info("the a value is {0}".format(a))
            assert a=="Incorrect Username or Password","it is mismatched"
            self.driver.close()
        except Exception as e:
            logging.info("failed with invalid username or password  {}".format(e))
            self.driver.save_screenshot(screens_path + os.path.sep + "invalid_login_"+str(flag)+".png")
            assert None, "failed to invalid username or password "

    def Submit_butn_enabled(self):
        try:
            self.driver = webdriver.Chrome()
            self.driver.implicitly_wait(30)
            self.driver.get(url)
            self.driver.maximize_window()
            element = self.driver.find_element_by_class_name(sign_in).is_enabled()
            logging.info("the checking for button {0}".format(element))
            self.driver.close()
        except Exception as e:
            logging.info("failed with invalid username or password  {}".format(e))
            self.driver.save_screenshot(screens_path + os.path.sep + "Submit_butn_enabled.png")
            assert None, "failed to invalid username or password "


    def login_page(self,browser='chrome'):
        if browser.lower() == 'chrome':
            self.driver = webdriver.Chrome()
        elif browser.lower() == 'firefox':
            self.driver = webdriver.Firefox()
        else:
            assert None,"Browser name wrong"

        self.driver.implicitly_wait(30)
        self.driver.get(url)
        try:
            self.driver.maximize_window()
            t_title = self.driver.title
            logging.info("the title is{0}".format(t_title))
            self.driver.save_screenshot(screens_path + os.path.sep + "login_page1.png")
            assert "NetApp Login Page" == t_title, "The title is not matched"
            logging.info("the title is matched succefully")
            self.driver.find_element_by_id(username_id).send_keys(self.user)
            self.driver.find_element_by_id(password_name).send_keys(self.pwd)
            self.sign = self.driver.find_element_by_class_name(sign_in).click()
            logging.info("login successfully")
            crrt_url = self.driver.current_url
            if "http://ctl.eng.netapp.com/"==crrt_url:
                logging.info("the current url is matched successfully")
            else:
                logging.info("Invalid,username or password")
                self.driver.save_screenshot(screens_path + os.path.sep + "login_page2.png")
                assert None,"Invalid,username or password"

        except Exception as e:
            logging.info("failed to login reservation page with error {}".format(e))
            self.driver.save_screenshot(screens_path + os.path.sep + "invalid_login_"+str(self.flag)+".png")
            assert None, "failed to login reservation page with error"
        # self.Submit_butn_enabled()

    def reserve_cluster(self):
        try:
            logging.info("here add the reservstion")
            resv_clust = self.driver.find_element_by_link_text(resrv_clus_link).text
            logging.info("the text is inside page{0}".format(resv_clust))
            self.driver.save_screenshot(screens_path + os.path.sep + "reserve_cluster1.png")
            assert "Reserve Cluster" == resv_clust, "the text is mismatched "
            resv_clust = self.driver.find_element_by_link_text(resrv_clus_link).click()
            logging.info("the assert is ok")
            resv_add = self.driver.find_element_by_link_text(resrv_add_link).text
            logging.info("the text is add reservation{0}".format(resv_add))
            self.driver.save_screenshot(screens_path + os.path.sep + "reserve_cluster2.png")
            assert "Reservation Add" == resv_add, "the text is mismatched "
            resv_add = self.driver.find_element_by_link_text(resrv_add_link).click()
            logging.info("the assert is Success with add resrv")
            time.sleep(4)
            crrt_url1 = self.driver.current_url
            if "http://ctl.eng.netapp.com/reservation/create/" == crrt_url1:
                logging.info("the current url is matched successfully")
            else:
                logging.info("the element is not clickable at the point")
                self.driver.save_screenshot(screens_path + os.path.sep + "reserve_cluster3.png")
                assert None, "the element is not clickable at the point"
        except Exception as e:
            logging.info("failed to click the reservation add button page with error {}".format(e))
            self.driver.save_screenshot(screens_path + os.path.sep + "reserve_cluster4.png")
            assert None, "failed to click the reservation add button page with error"

    def testbed_resource(self):
        try:
            self.driver.find_element_by_id(add_testbed_tab_id).click()
            self.driver.find_element_by_xpath(Fas_Vsim_tab_xpath).click()
            web1 = WebDriverWait(self.driver, 60).until(EC.element_to_be_clickable((By.ID, testbed_type_id)))
            web1.click()
            web2 = WebDriverWait(self.driver, 60).until(EC.element_to_be_clickable((By.XPATH, testbed_type_option_xpath)))
            web2.click()
            web = WebDriverWait(self.driver, 50).until(EC.element_to_be_clickable((By.ID, add_testbed_kart_id)))
            web.click()
            logging.info("the testbed fields added successfully")
        except Exception as e:
            logging.info("failed to submit the button with error {} ".format(e))
            self.driver.save_screenshot(screens_path + os.path.sep + "testbed_resource.png")
            assert None, "failed to submit the button with error"

    def clint_details(self):
        try:
            logging.info("the client option started")
            t_title1 = self.driver.title
            logging.info("the title is in inside{0} ".format(t_title1))
            self.driver.save_screenshot(screens_path + os.path.sep + "clint_details1.png")
            assert "CTL - Reservation Add" == t_title1, "the inside page title is mismatched"
            logging.info("the inside title validation is success")
            self.driver.find_element_by_id(add_clients_tab_id).click()
            clint_title = self.driver.find_element_by_xpath(verf_title_xpath).text
            logging.info("the get client title inside{0} ".format(clint_title))
            self.driver.save_screenshot(screens_path + os.path.sep + "clint_details2.png")
            assert "General Compute/Clients" == clint_title, "inside client page title is mismatched"
            logging.info("the client title is matched success")
            self.driver.find_element_by_id(add_linux_id).clear()
            self.driver.find_element_by_id(add_linux_id).send_keys(linux)
            self.driver.find_element_by_id(add_win_id).clear()
            self.driver.find_element_by_id(add_win_id).send_keys(windows)
            self.driver.find_element_by_id(add_client_tab_id).click()
            logging.info("the client details are entered  successfully")
        except Exception as e:
            logging.info("failed to fill the details of clients with error {} ".format(e))
            self.driver.save_screenshot(screens_path + os.path.sep + "clint_details3.png")
            assert None, "failed to fill the details of clients with error"

    def proj_details_valid(self):
        try:
            logging.info("the project details are started")
            proj_title = self.driver.find_element_by_xpath(proj_title_xpath).text
            logging.info("the project details option details{0}".format(proj_title))
            self.driver.save_screenshot(screens_path + os.path.sep + "proj_details_valid1.png")
            assert "Project Details" == proj_title, "the project title is not matched"
            logging.info("the project title is matched success")
            self.driver.find_element_by_xpath(proj_type1_xpath).click()
            self.driver.find_element_by_xpath(proj_option_xpath).click()
            self.driver.find_element_by_name(proj_type2_name).send_keys(PD)
            self.driver.find_element_by_name(proj_type3_name).send_keys(PD)
            self.driver.find_element_by_id(submit_butn_id).click()
            logging.info("All details are entered successfully")
            logging.info("now validating, after reserving the cluster")
            web21 = WebDriverWait(self.driver, 60).until(EC.presence_of_element_located((By.XPATH, aftr_resrv_xpath))).text
            logging.info("after the reservation will get the status(text) {0}".format(web21))
            match_num_with_text = self.driver.find_element_by_xpath(match_with_num_xpath).text
            logging.info("after the reservation will get the status(number) {0} ".format(match_num_with_text))
            self.driver.save_screenshot(screens_path + os.path.sep + "proj_details_valid2.png")
            assert match_num_with_text in web21, "the condition is failed with mismatched"
            logging.info("the condition is success with ID")
            match_with_status = self.driver.find_element_by_xpath(status_xpath).text
            logging.info("the status text is {0}".format(match_with_status))
            self.driver.save_screenshot(screens_path + os.path.sep + "proj_details_valid3.png")
            assert "looking_for_resources" == match_with_status, "the status is mismatched"
            logging.info("the reservation is completed successfully it will take some time to reserve it ")
        except Exception as e:
            logging.info("failed to Reservation details with error {} ".format(e))
            self.driver.save_screenshot(screens_path + os.path.sep + "proj_details_valid4.png")
            assert None,"failed to Reservation details with error"

    def Dashboard(self):
        '''this method is used to click the dashboard button'''
        try:
            dash_brd = self.driver.find_element_by_link_text(dash_brd_link).text
            logging.info("the text is {0}".format(dash_brd))
            self.driver.save_screenshot(screens_path + os.path.sep + "Dashboard1.png")
            assert "My Dashboard" == dash_brd, " the text is mismatched "
            dash_brd1 = self.driver.find_element_by_link_text(dash_brd_link).click()
            logging.info("the assert is Success with Execution add")
            crrt_url2 = self.driver.current_url
            if "http://ctl.eng.netapp.com/dashboard/" == crrt_url2:
                logging.info("the current url is matched successfully")
            else:
                logging.info("the element is not clickable at the point for dashboard")
                self.driver.save_screenshot(screens_path + os.path.sep + "Dashboard2.png")
                assert None, "the element is not clickable at the point for dashboard"
        except Exception as e:
            logging.info("failed to click on dashboard with error {} ".format(e))
            self.driver.save_screenshot(screens_path + os.path.sep + "Dashboard3.png")
            assert None,"failed to click on dashboard "

    def Executetest(self):
        '''this method is regarding to reserve the exectuion add'''
        try:
            exe_test = self.driver.find_element_by_link_text(exe_test_link).text
            logging.info("the text is {0}".format(exe_test))
            self.driver.save_screenshot(screens_path + os.path.sep + "Executetest1.png")
            assert "Execute Test" == exe_test, " the text is mismatched "
            self.driver.find_element_by_link_text(exe_test_link).click()
            logging.info("the assert is Success with add exectn")
            exe_add_butn = WebDriverWait(self.driver, 200).until(EC.element_to_be_clickable((By.LINK_TEXT, exe_add_link)))
            exe_add_butn.click()
            exe_url2 = self.driver.current_url
            if "http://ctl.eng.netapp.com/execution/create/" == exe_url2:
                logging.info("the current url is matched successfully")
            else:
                logging.info("invalid url for the current page")
                self.driver.save_screenshot(screens_path + os.path.sep + "Executetest2.png")
                assert None, "invalid url "
            time.sleep(5)
            # other_ele = WebDriverWait(self.driver, 200).until(EC.visibility_of_element_located((By.XPATH, '//div/h2[contains(text(),"Execution Details")]')))
            # logging.info("the heading values {0}".format(other_ele))
            exe_add = WebDriverWait(self.driver, 200).until(EC.presence_of_element_located((By.XPATH, proj_title1_xpath))).text
            logging.info("the project details option details{0}".format(exe_add))
            self.driver.save_screenshot(screens_path + os.path.sep + "Executetest3.png")
            assert "Project Details" == exe_add, "the project title is not matched"
            logging.info("the project title is matched success")
            WebDriverWait(self.driver, 100).until(EC.element_to_be_clickable((By.XPATH, proj1_type1_xpath))).click()
            self.driver.find_element_by_xpath(proj_option1_xpath).click()
            self.driver.find_element_by_name(proj_type2_name1).send_keys(PD)
            self.driver.find_element_by_name(proj_type3_name1).send_keys(PD)
            self.driver.find_element_by_xpath(plan_file_xpath).send_keys(pln_file_path)
            self.driver.find_element_by_id(load_pln_file_id).click()
            exe_add_clint = WebDriverWait(self.driver, 100).until(EC.element_to_be_clickable((By.ID, add_exe_client_tab_id)))
            exe_add_clint.click()
            sub_add_clint = WebDriverWait(self.driver, 100).until(EC.element_to_be_clickable((By.ID, submit_clients_id)))
            sub_add_clint.click()
            WebDriverWait(self.driver, 100).until(EC.element_to_be_clickable((By.ID, submit_exe_butn_id))).click()
            logging.info("All details are entered successfully")
            web22 = WebDriverWait(self.driver, 60).until(EC.presence_of_element_located((By.XPATH, aftr_resrv_xpath))).text
            logging.info("after the execution will get the status(text) {0}".format(web22))
            match_num_with_text1 = self.driver.find_element_by_xpath(aftr_exe_xpath).text
            logging.info("after the execution will get the status(number) {0} ".format(match_num_with_text1))
            self.driver.save_screenshot(screens_path + os.path.sep + "Executetest4.png")
            assert match_num_with_text1 in web22, "the condition is failed with mismatched"
            logging.info("the condition is success with ID")
            match_with_status1 = self.driver.find_element_by_xpath(exe_status_xpath).text
            logging.info("the status text is {0}".format(match_with_status1))
            self.driver.save_screenshot(screens_path + os.path.sep + "Executetest5.png")
            assert "looking_for_resources" == match_with_status1, "the status is mismatched"
            logging.info("the reservation is completed successfully it will take some time to reserve it ")
        except Exception as e:
            logging.info("failed to Execution details with error {} ".format(e))
            self.driver.save_screenshot(screens_path + os.path.sep + "Executetest6.png")
            assert None,"failed to Execution details add"

    def logout(self):
        try:
            web2 = WebDriverWait(self.driver, 120).until(EC.element_to_be_clickable((By.XPATH, pick_option_signout_xpath)))
            web2.click()
            web3 = WebDriverWait(self.driver, 120).until(EC.element_to_be_clickable((By.LINK_TEXT, signout)))
            web3.click()
            logging.info("the ctl page logout successfully")
            self.driver.close()

        except Exception as e:
            logging.info("failed to logout the page with error {} ".format(e))
            self.driver.save_screenshot(screens_path + os.path.sep + "logout.png")
            self.driver.close()
            assert None,"Logout filed"


if __name__ == '__main__':
    pass


import os,sys
import pytest
sys.path.append(os.getcwd())
from resources.pageobject.ctl_reservation import Reservation_automation
from resources.locators.variable import *
from resources.locators.locator import *

res_obj=Reservation_automation(url,invalid_username,valid_password,PD,"invalid_username@")
# res_obj1=Reservation_automation(url,valid_user,invalid_password,PD,"invalid_password2@")
res_obj2=Reservation_automation(url,invalid_username,invalid_password,PD,"invalid_username_and_password@")
res_obj3=Reservation_automation(url,user,EMPTY,invalid_password,"empty_username@")
res_obj4=Reservation_automation(url,valid_user,EMPTY,PD,"empty_password@")
res_obj5=Reservation_automation(url,EMPTY,EMPTY,PD,"empty_username_and_password@")
res_obj6=Reservation_automation(url,user,pwd,PD,"Valid_usr_and_pwd@")
#
# def setup_module(module):
#     res_obj.login_page()
#
# def teardown_module(module):
#     res_obj.logout()
# #

@pytest.fixture(scope='function')
def set_tear(request):
    print('\n Setup')
    res_obj.login_page()
    # res_obj1.login_page()
    res_obj2.login_page()
    res_obj3.login_page()
    res_obj4.login_page()
    res_obj5.login_page()
    res_obj6.login_page()
    yield
    res_obj.logout()
    print('\n Teardown')

# @pytest.mark.marker1
# class Testinvalid_details(object):
#     def test_invalid_username(self):
#         res_obj.invalid_login(invalid_username,valid_password,"invalid_username")
#     def test_invalid_password(self):
#         res_obj.invalid_login(valid_user,invalid_password,"invalid_password")
#     def test_invalid_username_and_password(self):
#         res_obj.invalid_login(invalid_username,invalid_password,"invalid_username_and_password")
#     def test_empty_username(self):
#         res_obj.invalid_login(EMPTY,invalid_password,"empty_username")
#     def test_empty_password(self):
#         res_obj.invalid_login(valid_user,EMPTY,"empty_password")
#     def test_empty_username_and_password(self):
#         res_obj.invalid_login(EMPTY,EMPTY,"empty_username_and_password")
#     def test_validate_button(self):
#         res_obj.Submit_butn_enabled()

@pytest.mark.parametrize('u,p,flag',[(invalid_username,valid_password,"invalid_username"),(valid_user,invalid_password,"invalid_password"),(invalid_username,invalid_password,"invalid_username_and_password"),
                                     (EMPTY,invalid_password,"empty_username"),(valid_user,EMPTY,"empty_password"),(EMPTY,EMPTY,"empty_username_and_password")])
@pytest.mark.marker1
def test_negative_scenarios(u,p,flag):
    res_obj.invalid_login(u,p,flag)
@pytest.mark.marker1
def test_validate_button():
    res_obj.Submit_butn_enabled()

@pytest.mark.marker2
def test_reserv_add(set_tear):
    res_obj.reserve_cluster()
    res_obj.testbed_resource()
    res_obj.clint_details()
    res_obj.proj_details_valid()

@pytest.mark.marker3
def test_execution_add(set_tear):
    # res_obj.Executetest()
    res_obj6.Dashboard()











