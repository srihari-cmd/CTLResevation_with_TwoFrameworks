import os
from selenium import webdriver

# import sele_refer as refer
# other_ele = WebDriverWait(self.driver, 200).until(EC.visibility_of_element_located((By.XPATH, '//div/h2[contains(text(),"Execution Details")]')))
            # logging.info("the heading values {0}".format(other_ele))
# timestamp = datetime.strftime(datetime.now(),"%Y-%m-%d %H:%M:%S")
# print("timestamp",timestamp)
# self.driver.save_screenshot(screens_path + os.path.sep + "invalid_login_"+str(flag)+".png")
# self.driver.save_screenshot(screens_path + os.path.sep + "invalid_login1"+str(timestamp)+".png")
# filename = "%s/%s_%s.png" % ("C:/Users/sriharip/PycharmProjects/Py_With_Selenium/CTL/screenshots1", "invalid", timestamp)
# print("the filw",filename)
# self.driver.save_screenshot(filename)
# self.driver.save_screenshot(r'C:\\Users\\sriharip\\PycharmProjects\\Py_With_Selenium\\CTL\\screenshots1\\' + "invalid_login"+str(timestamp)+".png")
#     self.driver.save_screenshot(screens_path + os.path.sep + list1)
# print("pathh",screens_path + os.path.sep + "invalid_login1"+str(timestamp)+".png")
DOWNLOADS_XP = '//*[@id="downloads"]/a'
ABOUT_XP = '//*[@id="about"]/a'

cur_dir = os.getcwd()
# Create a new directory to store saved screenshots
screens_path = cur_dir + os.path.sep + "screens"
if not os.path.exists(screens_path):
    os.mkdir(screens_path)

try:
    driver = webdriver.Chrome()

    driver.maximize_window()
    driver.get("https://www.python.org/")

    # about_elem = driver.find_element_by_xpath(refer.ABOUT_XP)
    about_elem = driver.find_element_by_xpath(ABOUT_XP)
    about_elem.click()

    driver.save_screenshot(screens_path + os.path.sep + "about.png")
    driver.back()

    # downloads_elem = driver.find_element_by_xpath(refer.DOWNLOADS_XP)
    downloads_elem = driver.find_element_by_xpath(DOWNLOADS_XP)
    downloads_elem.click()

    driver.save_screenshot(screens_path + os.path.sep + "downloads.png")
    driver.back()
except Exception as e:
    print("Exception while executing script. %s" % e)
finally:
    driver.quit()