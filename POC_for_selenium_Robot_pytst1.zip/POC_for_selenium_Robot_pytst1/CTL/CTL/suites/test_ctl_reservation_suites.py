import os,sys
import pytest
sys.path.append(os.getcwd())
from resources.pageobject.ctl_reservation import Reservation_automation
from resources.locators.variable import *
from resources.locators.locator import *

res_obj=Reservation_automation()

@pytest.fixture(scope='module')
def set_tear(request):
    print('\n Setup')
    res_obj.login_page()
    yield
    res_obj.logout()
    print('\n Teardown')

@pytest.mark.marker1
def test_reserv_add(set_tear):
    res_obj.reserve_cluster()
    res_obj.testbed_resource()
    res_obj.clint_details()
    res_obj.proj_details_valid()

@pytest.mark.marker2
def test_execution_add(set_tear):
    res_obj.Executetest()
    res_obj.Dashboard()

# @pytest.mark.marker1
# class Testinvalid_details(object):
#     def test_invalid_username(self):
#         res_obj.invalid_login(invalid_username,valid_password,"invalid_username")
#     def test_invalid_password(self):
#         res_obj.invalid_login(valid_user,invalid_password,"invalid_password")
#     def test_invalid_username_and_password(self):
#         res_obj.invalid_login(invalid_username,invalid_password,"invalid_username_and_password")
#     def test_empty_username(self):
#         res_obj.invalid_login(EMPTY,invalid_password,"empty_username")
#     def test_empty_password(self):
#         res_obj.invalid_login(valid_user,EMPTY,"empty_password")
#     def test_empty_username_and_password(self):
#         res_obj.invalid_login(EMPTY,EMPTY,"empty_username_and_password")
#     def test_validate_button(self):
#         res_obj.Submit_butn_enabled()

@pytest.mark.parametrize('u,p,flag',[(invalid_username,valid_password,"invalid_username"),(valid_user,invalid_password,"invalid_password"),(invalid_username,invalid_password,"invalid_username_and_password"),
                                     (EMPTY,invalid_password,"empty_username"),(valid_user,EMPTY,"empty_password"),(EMPTY,EMPTY,"empty_username_and_password")])
@pytest.mark.marker4
def test_negative_scenarios(u,p,flag):
    res_obj.invalid_login(u,p,flag)

@pytest.mark.marker3
def test_validate_button():
    res_obj.Submit_butn_enabled()

















































# def setup_module(module):
#     res_obj.login_page()
#
# def teardown_module(module):
#     res_obj.logout()
#
