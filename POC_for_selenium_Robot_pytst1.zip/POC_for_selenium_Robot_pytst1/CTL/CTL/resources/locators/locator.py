"""
This file contain page locators
"""
######login paths ######
error_msg_xpath = '//div[@class="error"]'

username_id = "username"
password_name = "password"
sign_in = "button"

resrv_clus_link= "Reserve Cluster"     #link
resrv_add_link= "Reservation Add"       #link
add_testbed_tab_id= "reservation-create-select-testbeds"       # id
Fas_Vsim_tab_xpath= '(//*[contains(text()," FAS/VSIM")])[1]'
testbed_type_id= "general-testbed-resource-testbed_type"     # id
testbed_type_option_xpath= '(//option[contains(text(),"2Vsim")])[1]'
add_testbed_kart_id= "general-testbed-resource-add-to-cart"   # id
add_clients_tab_id= "reservation-create-select-clients"    # id
verf_title_xpath = '//h2[contains(text(),"General Compute/Clients")]'
add_linux_id= "client_type-linux_rhel7-quantity"    # id
add_win_id= "client_type-windows-quantity"     # id
add_client_tab_id= "clienttypes-selection-save"   # id
proj_title_xpath= '//h2[contains(text(),"Project Details")]'
proj_type1_xpath='(//div[@class="multiselect__select"])[2]'
proj_option_xpath= '//span[contains(text(),"other")]'
proj_type2_name= "projectSelected"    # name
proj_type3_name= "reasonSelected"    # name
submit_butn_id= "reservation-create-submit"   # id
aftr_resrv_xpath= '//div[@class="col-md-12 col-lg-4"]'
match_with_num_xpath= '(//td[@class="reservation-describe-table-value-field"])[1]'
status_xpath= '(//span[@class="badge badge-primary"])[1]'
pick_option_signout_xpath = '(//span[contains(text(),"sriharip")])[1]'
dash_brd_link = "My Dashboard"

exe_test_link= "Execute Test"
exe_add_link= "Execution Add"

proj_title1_xpath=  '//h2[contains(text(),"Project Details")]'
proj1_type1_xpath=  '(//div[@class="multiselect__select"])[1]'
proj_option1_xpath= '(//span[contains(text(),"other")])[1]'
proj_type2_name1= 'projectSelected'    # name
proj_type3_name1= 'reasonSelected'    # name
plan_file_xpath= '//input[@class="form-control no-overlap"]'
load_pln_file_id= "execution-create-plan_validate"
add_exe_client_tab_id= "execution-create-add-client"
submit_clients_id= "clienttypes-selection-save"
submit_exe_butn_id= "execution-create-submit"   # id


aftr_exe_xpath = '(//td[@class="execution-describe-table-value-field"])[1]'
exe_status_xpath = '(//span[@class="badge badge-success"])[1]'

signout= "Sign Out"











'''
######### reserve the cluster #############
resrv_clus_xpath = "//span[contains(text(),'Reserve Cluster')]"

########## Add option #########
resrv_add_xpath = "//a[contains(text(),'Reservation Add')]"

########## Add button #########
# add_testbed_tab_id = "reservation-create-select-testbeds"
add_testbed_tab_xpath = '(//button[@type="button"])[3]'

##########Fas/vsim button ########
# Fas_Vsim_tab_xpath = "(//i[@class='fa fa-hdd-o'])[2]"
Fas_Vsim_tab_xpath = '(//*[contains(text()," FAS/VSIM")])[1]'

########### testbed type ################

testbed_type_id = "general-testbed-resource-testbed_type"
testbed_type_option_xpath = '(//option[contains(text(),"2Vsim")])[1]'


######### submit button ########
# add_testbed_kart_xpath = "//button[@class='btn btn-large btn-success']"
add_testbed_kart_id = "general-testbed-resource-add-to-cart"


######### reserve clients page #########
add_clients_tab_id = "reservation-create-select-clients"

####### verify the title of clients ############


######### reserve clients page #########
add_linux_id = "client_type-linux_rhel7-quantity"
add_win_id = "client_type-windows_8-quantity"

######### submit the client page ############
add_client_tab_xpath = '//i[@class="fa fa-check"]'

########### verify the project details #########
proj_title_xpath = '//h2[contains(text(),"Project Details")]'

########### add the project details #########
proj_type1_xpath = '(//div[@class="multiselect__select"])[2]'
proj_option_xpath = '//span[contains(text(),"other")]'
proj_type2_xpath = '(//input[@type="text"])[3]'
proj_type3_xpath = '(//input[@type="text"])[4]'

########### submit the project details page #########
submit_butn_id = "reservation-create-submit"

######## verifying after reserve the cluster reservation ##########
aftr_resrv_xpath = '//div[@class="col-md-12 col-lg-4"]'
match_with_num_xpath = '(//td[@class="reservation-describe-table-value-field"])[1]'
status_xpath = '(//span[@class="badge badge-primary"])[1]'


########## logout ###############

signout_xpath = '//li/a[contains(text(),"Sign Out")]'

'''















