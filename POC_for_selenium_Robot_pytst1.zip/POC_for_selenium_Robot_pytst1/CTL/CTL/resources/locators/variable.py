######## this page contains variables ########

url = "http://ctl.eng.netapp.com/"
user = "sriharip"
pwd = "Vij5889amna"
PD = "other"

invalid_username= "harippp"
invalid_password= "Vij5888df"
valid_user= "sriharip"
valid_password=  "Vij5889amna"
EMPTY = ""

pln_file_path = "/u/sriharip/hari1.plan"


linux = "10"
windows = "5"

