import os,sys
sys.path.append(os.getcwd())
from resources.pageobject.ctl_reservation import Reservation_automation
a=Reservation_automation()

def ctl_reservation():

    a.login_page()

    #a.reserve_cluster()
    # a.testbed_resource()
    # a.clint_details()
    # a.proj_details_valid()

    a.logout()

ctl_reservation()

