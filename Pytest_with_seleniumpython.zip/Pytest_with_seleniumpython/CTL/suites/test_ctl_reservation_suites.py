import os,sys
import pytest
sys.path.append(os.getcwd())
from resources.pageobject.ctl_reservation import Reservation_automation
from resources.locators.variable import *
from resources.locators.locator import *

res_obj=Reservation_automation()

@pytest.fixture(scope='module')
def set_tear(request):
    print('\n Setup')
    res_obj.login_page()
    yield
    res_obj.logout()
    print('\n Teardown')

@pytest.mark.marker1
def test_reserv_add(set_tear):
    res_obj.reserve_cluster()
    res_obj.testbed_resource()
    res_obj.clint_details()
    res_obj.proj_details_valid()

@pytest.mark.marker2
def test_execution_add(set_tear):
    res_obj.Executetest()
    res_obj.client_details_executionadd()
    res_obj.validation_after_reserve_cluster()
    res_obj.Dashboard()

# this code for check with invalid credintials other way
# @pytest.mark.marker1
# class Testinvalid_details(object):
#     def test_invalid_username(self):
#         res_obj.invalid_login(invalid_username,valid_password,"invalid_username")
#     def test_invalid_password(self):
#         res_obj.invalid_login(valid_user,invalid_password,"invalid_password")
#     def test_invalid_username_and_password(self):
#         res_obj.invalid_login(invalid_username,invalid_password,"invalid_username_and_password")
#     def test_empty_username(self):
#         res_obj.invalid_login(EMPTY,invalid_password,"empty_username")
#     def test_empty_password(self):
#         res_obj.invalid_login(valid_user,EMPTY,"empty_password")
#     def test_empty_username_and_password(self):
#         res_obj.invalid_login(EMPTY,EMPTY,"empty_username_and_password")
#     def test_validate_button(self):
#         res_obj.Submit_butn_enabled()

@pytest.mark.parametrize('u,p,flag',[(invalid_username,valid_password,"invalid_username"),(valid_user,invalid_password,"invalid_password"),(invalid_username,invalid_password,"invalid_username_and_password"),
                                     (EMPTY,invalid_password,"empty_username"),(valid_user,EMPTY,"empty_password"),(EMPTY,EMPTY,"empty_username_and_password")])
@pytest.mark.marker3
def test_negative_scenarios(u,p,flag):
    res_obj.invalid_login(u,p,flag)

@pytest.mark.marker3
def test_validate_button():
    res_obj.Submit_butn_enabled()

@pytest.mark.marker4
def test_all_url_options(set_tear):
    res_obj.check_url_daskboard()
    res_obj.check_url_reservationadd()
    res_obj.check_url_executionadd()
    res_obj.check_url_reservationlist()
    res_obj.check_url_help()
    res_obj.check_url_resources_clintlist()
    res_obj.check_url_executionlist()
    res_obj.check_url_resources_testbedlist()

'''@pytest.mark.marker4
def test_dashboard_url(set_tear):
    res_obj.check_url_daskboard()
@pytest.mark.marker4
def test_reserv_add_url(set_tear):
    res_obj.check_url_reservationadd()
@pytest.mark.marker4
def test_exectin_add_url(set_tear):
    res_obj.check_url_executionadd()
@pytest.mark.marker4
def test_reserv_list_url(set_tear):
    res_obj.check_url_reservationlist()
@pytest.mark.marker4
def test_help_url(set_tear):
    res_obj.check_url_help()
@pytest.mark.marker4
def test_resorce_clintlist_url(set_tear):
    res_obj.check_url_resources_clintlist()
@pytest.mark.marker4
def test_exectin_list_url(set_tear):
    res_obj.check_url_executionlist()
@pytest.mark.marker4
def test_resorce_testbedlist_url(set_tear):
    res_obj.check_url_resources_testbedlist()
 '''

@pytest.mark.marker5
def test_submit_buttn_disable(set_tear):
    res_obj.submit_buttn_should_diable_executn_add()

@pytest.mark.marker6
def test_client_num_shdbe_digits(set_tear):
    res_obj.Executetest()
    res_obj.client_values_should_be_digits()

@pytest.mark.marker7
def test_client_num_shdbe_allow_fourdigits(set_tear):
    res_obj.Executetest()
    res_obj.client_values_should_be_allow_four_digits()

@pytest.mark.marker8
def test_client_button(set_tear):
    res_obj.Executetest()
    res_obj.check_with_client_button()

@pytest.mark.marker9
def test_reserv_requst_button(set_tear):
    res_obj.Executetest()
    res_obj.check_with_reservtn_submit_button()

@pytest.mark.marker10
def test_reservatn_sbmit_button(set_tear):
    res_obj.reservtnadd_submit_buttn()

@pytest.mark.marker11
def test_reservatnadd_clients_should_allow_digits(set_tear):
    res_obj.reserve_cluster()
    res_obj.testbed_resource()
    res_obj.reservtnadd_client_shouldbe_allow_onlydigits()

@pytest.mark.marker12
def test_reservatnadd_clients_should_allow_fourdigits(set_tear):
    res_obj.reserve_cluster()
    res_obj.testbed_resource()
    res_obj.reservtnadd_client_shouldbe_allow_onlyfourdigits()

@pytest.mark.marker13
def test_clint_num_and_clintbuttn(set_tear):
    res_obj.reserve_cluster()
    res_obj.testbed_resource()
    res_obj.validate_with_both_clints_allow_digts_and_clintbtton()

@pytest.mark.marker14
def test_reserv_reqst_submtbuttn(set_tear):
    res_obj.reserve_cluster()
    res_obj.testbed_resource()
    res_obj.clint_details()
    res_obj.validate_with_reservrequst_submitbtton()














































