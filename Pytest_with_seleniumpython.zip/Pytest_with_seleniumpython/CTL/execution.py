import os

os.system('python -m pytest suites\test_ctl_reservation_suites.py -k test_ctrl --html=sample.html')

# this is use to run for mark in pytest
os.system('python -m pytest suites\test_ctl_reservation_suites.py -k marker1 -v --html=sample.html')
os.system('python -m pytest suites\test_ctl_reservation_suites.py -k marker4 -v --html=sample.html')

