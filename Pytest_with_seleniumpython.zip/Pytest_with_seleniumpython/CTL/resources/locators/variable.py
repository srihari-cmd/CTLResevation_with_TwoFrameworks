######## this page contains variables ########

url = "http://ctl.eng.netapp.com/"
user = "sriharip"
pwd = "Vij5889amna"
PD = "other"
b1 = "Invalid input. Must be an integer. Minimum is 0."
b2 = "Specified quantity exceeds the number in the system."

invalid_username= "harippp"
invalid_password= "Vij5888df"
valid_user= "sriharip"
valid_password=  "Vij5889amna"
EMPTY = ""
PD2 = "eee@#$"
pln_file_path = "/u/sriharip/hari1.plan"
PD3 = ""
PD1 = "12345"
linux = "10"
windows = "5"

